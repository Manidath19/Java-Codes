/**
 * 
 */
/**
 * @author manid
 *
 */
module LinkedList {
}