package org.learning;

import java.util.LinkedList;

public class App {

	public static void main(String[] args) {
		LinkedList<String> countries = new LinkedList<>();
		countries.add("India");
		countries.add("USA");
		countries.add("BRAZIL");
		new App().displayCountries(countries);
		System.out.println("***********");
		countries.add(1, "CANADA");
		new App().displayCountries(countries);
		System.out.println("***********");
		countries.remove(3);
		new App().displayCountries(countries);
		System.out.println("***********");
		countries.set(0, "Mexico");
		new App().displayCountries(countries);
	}
	void displayCountries(LinkedList<String> list) {
		for (String countries: list) {
			System.out.println(countries);
		}
	}

}
