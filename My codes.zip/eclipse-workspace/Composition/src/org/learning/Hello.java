package org.learning;
import org.learning.laptop.Laptop;
import org.learning.laptop.components.*;

public class Hello {

	public static void main(String[] args) {
		//Laptop lappy=new Laptop();
		//System.out.println(lappy.getProcessor().getBrand());
		Processor processor=new Processor("intel", "7200U", 7, 4, 4, "6MB", "2.5GHZ", "2.5GHZ", "3.1GHZ");
	    GraphicsCard graphicscard = new GraphicsCard("NVIDIA", 1050, "8 GB");
	    Laptop gamingLaptop = new Laptop(17f, processor, "DDR4", "2TB", graphicscard, null, "Backlit");
	    System.out.println(gamingLaptop);
	    gamingLaptop.gamingMode();
	    System.out.println("Gaming mode on");
	    System.out.println("new frequency "+gamingLaptop.getProcessor().getFrequency());
	}

}
