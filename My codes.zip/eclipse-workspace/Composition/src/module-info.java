/**
 * 
 */
/**
 * @author manid
 *
 */
module Composition {
}