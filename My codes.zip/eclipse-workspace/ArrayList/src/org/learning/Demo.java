package org.learning;

import java.util.ArrayList;

public class Demo {

	static ArrayList<String> listNames = new ArrayList<>();
	public static void main(String[] args) {
		listNames.add("Mani");
		listNames.add("kittu");
		listNames.add("PC");
		listNames.add("Sindhu");
		listNames.add("Prasanna");
		//System.out.println(listNames);
		Demo demo = new Demo();
		demo.displayNames(listNames);
		System.out.println("**************");
		demo.modifyName(0, "Mahesh");
		demo.displayNames(listNames);
		System.out.println("**************");
		int position = demo.search("kittu");
		if(position!= -1) {
			demo.modifyName(position, "Ramesh");
			demo.displayNames(listNames);
		}else {
			System.out.println("not found");
		}
	}
	void displayNames(ArrayList<String> names) {
		for(String name:names) {
			System.out.println(name);
		}
	}
	
	void modifyName(int position, String Name) {
		listNames.set(position, Name);
	}
	int search(String Name) {
		return listNames.indexOf(Name);
	}

}
