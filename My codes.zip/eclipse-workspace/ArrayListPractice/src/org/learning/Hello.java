package org.learning;

import java.util.ArrayList;

public class Hello {

	static ArrayList<String> listNames = new ArrayList<>();

	public static void main(String[] args) {
		listNames.add("Mani");
		listNames.add("Kittu");
		listNames.add("PC");
		listNames.add("Sindhu");
		listNames.add("Prasanna");
		System.out.println(listNames);
		System.out.println("*************");
		Hello app = new Hello();
		app.displayNames(listNames);
		System.out.println("*************");
		app.modifyByPosition(0, "Mahesh");
		app.displayNames(listNames);
		System.out.println("*************");
		int position = app.search("Kittu");
		if(position>=0) {
			app.modifyByPosition(position, "Suresh");
			app.displayNames(listNames);
			
		}
		else {
			app.displayNames(listNames);
		}
		
	}
	void displayNames(ArrayList<String> names) {
		for(String name : names) {
		System.out.println(name);
		}
	}
	void modifyByPosition(int position, String newName) {
		listNames.set(position, newName);
	}
	int  search(String name) {
		return listNames.indexOf(name);
	}
}
