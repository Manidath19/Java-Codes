package org.learning;

import java.util.ArrayList;

public class App {
	static ArrayList<String> listNames = new ArrayList<>();

	public static void main(String[] args) {
		listNames.add("Mani");
		listNames.add("Kittu");
		listNames.add("PC");
		listNames.add("Sindhu");
		listNames.add("Prasanna");
		System.out.println(listNames);
		System.out.println("*************");
		App app = new App();
		app.displayNames(listNames);
		System.out.println("*************");
		app.removeNameByPosition(0);
		app.displayNames(listNames);
		System.out.println("*************");
		app.removeNameByName("Kittu");
		app.displayNames(listNames);
	}
	void displayNames(ArrayList<String> names) {
		for(String name : names) {
		System.out.println(name);
		}
	}
	void removeNameByPosition(int position) {
		listNames.remove(position);	
	}
	void removeNameByName(String name) {
		listNames.remove(name);
	}

}
