package org.learning;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class App {

	public static void main(String[] args) {
		List<String> countries = new ArrayList<>();
		countries.add("India");
		countries.add("USA");
		countries.add("Canada");
		countries.add("Australia");
		new App().displayList(countries);
		
		List<String> numbers = new LinkedList<>();
		numbers.add("one");
		numbers.add("two");
		numbers.add("three");
		numbers.add("four");
		new App().displayList(numbers);
		

	}
	void displayList(List<String> list) {
		for(String value:list) {
			System.out.println(value);
		}
		
	}

}
