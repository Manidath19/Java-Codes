package org.learning;

public class App {

	public static void main(String[] args) {
		App app = new App();
		app.case1(10, 0);

	}
	public void case1(int x, int y) {
		try {
			System.out.println(x/y);
		} catch(Exception e) {
			System.out.println("y is 0");
		}
		
	}

}
