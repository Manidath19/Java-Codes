package org.learning;

public class Hello {

	public static void main(String[] args) {
		int x = 2;
		try {
			System.out.println("outcome of:"+x/0);
			
		}catch(RuntimeException e){
			System.out.println("runtime exception");
			e.printStackTrace();
		}catch(Exception e) {
			System.out.println("inside exception");
		}
		finally {
			System.out.println("gets printed anyway");
		}

	}

}
