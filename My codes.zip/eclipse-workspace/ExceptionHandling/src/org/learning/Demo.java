package org.learning;

public class Demo {

	public static void main(String[] args) {
	int x = 4;
	try {
		
		System.out.println("outcome of:"+x/0);
		
	}
	/*
	 * catch(ArithmeticException e){ System.out.println("Arithematic exception"); }
	 */
	catch(Exception e) {
		e.printStackTrace();
		
		System.out.println("inside exception block");
	}
	}

}
