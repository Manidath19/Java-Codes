/**
 * 
 */
/**
 * @author manid
 *
 */
module ExceptionHandling {
}