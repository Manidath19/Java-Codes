package org.learning;
import java.util.List;
import java.util.Collections;
import java.util.LinkedList;
import java.util.ListIterator;
public class App {

	public static void main(String[] args) {
		List<String> countries = new LinkedList<>();
		countries.add("India");
		countries.add("USA");
		countries.add("Canada");
		countries.add("Mexico");
		new App().displayList(countries);
		System.out.println("************");
		countries.sort(null);
		new App().displayList(countries);
		System.out.println("************");
		Collections.reverse(countries);
		new App().displayList(countries);
		
	}
	void displayList(List<String> list) {
		ListIterator<String> iterator= list.listIterator();
		while(iterator.hasNext()) {
			System.out.println("Element: "+iterator.next());
		}
		
	}

}
