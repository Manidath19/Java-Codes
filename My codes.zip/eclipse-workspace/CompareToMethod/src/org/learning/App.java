package org.learning;
import java.util.ArrayList;
public class App {

	public static void main(String[] args) {
		/*
		 * int result; ArrayList<String> list = new ArrayList<>(); list.add("a"); result
		 * = list.get(0).compareTo("a"); System.out.println(result);
		 */
		Integer x = 1;
		Integer y = 2;
		System.out.println(x.compareTo(y));

	}

}
