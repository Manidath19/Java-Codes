/**
 * 
 */
/**
 * @author manid
 *
 */
module CompareToMethod {
}