/**
 * 
 */
/**
 * @author manid
 *
 */
module Fib {
}