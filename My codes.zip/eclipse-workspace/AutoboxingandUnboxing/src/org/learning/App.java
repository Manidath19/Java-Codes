package org.learning;

import java.util.ArrayList;

public class App {
	
	public static void main(String[] args) {
		ArrayList<Integer> studentnumbers = new ArrayList<>();
		studentnumbers.add(21);
		System.out.println(studentnumbers.get(0));

	}

}
