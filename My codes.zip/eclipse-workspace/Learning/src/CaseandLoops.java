
public class CaseandLoops {

	public static void main(String[] args) {
		/*
		 * int x = 2; switch (x) { case 1: System.out.println("when 1"); break; case 2:
		 * System.out.println("when 2"); break; case 3: System.out.println("when 3");
		 * break; default: System.out.println("Other than 1, 2, 3"); break; }
		 */
		/*
		 * char x = 'C'; switch (x) { case 'a': case 'A': System.out.println("when a");
		 * break; case 'b': case 'B': System.out.println("when b"); break; case 'c':
		 * case 'C': System.out.println("when c"); break; default:
		 * System.out.println("Other than a, b, c"); break; }
		 */
		/*
		 * String name = "Mani"; switch (name.toLowerCase()) { case "mani":
		 * System.out.println("name is " + name); break; case "kittu":
		 * System.out.println("name is " + name); break; case "pc":
		 * System.out.println("name is " + name); break;
		 * 
		 * }
		 */
		/*
		 * for(int i=15;i<20;i++) { System.out.println(i);
		 * 
		 * }
		 */
		/*for loop
		 * int num = 9; boolean flag = true; for (int i = 2; i <= num / 2; i++) { if
		 * (num % i == 0) { flag = false; break; } } if (!flag) { System.out.println(num
		 * + " is not a prime"); } else { System.out.println(num + " is  a prime"); }
		 */
		/* while loop
		 * int i =1; while(i<=10) { System.out.println(i); i++;
		 * 
		 * }
		 */
		/* do while loop
		 * int i =0; do { System.out.println(i); i++; } while(i<=10);
		 */
		//loops for multiple variables
		/* 
		 * for (int i= 1,j=10;i<=10 && j<=10;i++,j--) { i++; j--;
		 * System.out.println("i="+i+"and j="+j); }
		 */
		/*
		 * int i=0,j=0; while(i<10 && j<9) { i++; j++;
		 * System.out.println("i="+i+"and j="+j); }
		 */
		
		/*
		 * int i=1,j=1; do { i++; j++; System.out.println("i="+i+"and j="+j);
		 * }while(i<10 && j<9);
		 */
		//break and continue
		
		/*
		 * for(int i =1;i<=10;i++) {
		 * 
		 * if(i ==6) { continue; } System.out.println(i); }
		 */
		//Nested Loops
		/*
		 * for(int i=1;i<=5;i++) {
		 * 
		 * for(int j=1;j<=i;j++) { System.out.print('@'); } System.out.println(); }
		 */
		/* sum of digits in a number
		 * int value = 123456; int sumofDigits = 0; while (true) { sumofDigits =
		 * sumofDigits + value % 10; value = value / 10; if (value < 10) { break; } }
		 * sumofDigits = sumofDigits + value; System.out.println("Sum of Digits is " +
		 * sumofDigits);
		 */
	
	}

}

