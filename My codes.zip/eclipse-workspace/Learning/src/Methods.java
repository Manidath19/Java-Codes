
import org.learning.*;
public class Methods {

	/* basic method with parameters
	 * public static void main(String[] args) { loop(1, 10);
	 * System.out.println("*********************"); loop(10,20); }
	 * 
	 * public static void loop(int i,int finalValue) {
	 * 
	 * while (i <= finalValue) { System.out.println(i); i++; } }
	 */
	/*method with return type
	 * public static void main(String[] args) {
	 * System.out.println("Area of the Rectangle is: " + areaofRectangle(1.5, 1.1));
	 * // areaofRectangle(1.5, 1.1);
	 * 
	 * }
	 * 
	 * public static double areaofRectangle(double length, double width) {
	 * 
	 * return length * width;
	 * 
	 * }
	 */
	/*method overloading
	 * public static void main(String[] args) {
	 * System.out.println("Area of Rectangle" + area(14.5, 5.5));
	 * System.out.println("Area of Square" + area(5)); }
	 * 
	 * public static double area(double length, double width) { return length *
	 * width; }
	 * 
	 * public static double area(double side) { return side * side; }
	 * 
	 * public static int area(int side) { return side * side; }
	 */
	/*
	 * method overloading with diff parameters public static void main(String[]
	 * args) { System.out.println("adding 2 ints" + add(1, 2));
	 * System.out.println("adding 1 int & one float" + add(1, 2.5f));
	 * System.out.println("adding 2 doubles" + add(1.5, 2.5)); }
	 * 
	 * public static int add(int a, int b) { return a + b; }
	 * 
	 * public static float add(int a, float b) { return a + b; }
	 * 
	 * public static double add(double a, double b) { return a + b; }
	 */
	
	
	public static void main(String[] args) {
		System.out.println("*******");
		Calculate prime=new Calculate();
		if(prime.isPrime(30)) {
			System.out.println("Number is Prime");
		}else {
			System.out.println("Number is not prime");
		}
	}
}
