package org.learning;

public class Calculate {
public boolean isPrime(int num) {
		
		int temp;   
		boolean isPrime = true; 
		   for (int i = 2; i <= num / 2; i++) {
			   temp=num%i;
			   if(temp == 0) { 
				   isPrime = false;
				   break; 
				   } } 
		
		 return isPrime;
		
	}
public boolean isPrime(double doubleValue) {
	int num=(int)doubleValue;
		
		int temp;   
		boolean isPrime = true; 
		   for (int i = 2; i <= num / 2; i++) {
			   temp=num%i;
			   if(temp == 0) { 
				   isPrime = false;
				   break; 
				   } } 
		
		 return isPrime;

}

public boolean isPrime1(int num) {
	int temp;
	boolean isPrime1=true;
			for(int i=2; i<=num/2;i++) {
				temp=num%i;
						if(temp==0) {
							isPrime1=false;
							break;
						}		
			}
	
return isPrime1;
}
}
