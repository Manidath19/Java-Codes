
public class Decision {

	public static void main(String[] args) {
		/*
		 * int x=5; if(x == 6) { System.out.println("x value is 5"); }else {
		 * System.out.println(" value not 5"); }
		 */
	/*	boolean x = true;
		boolean y = true;
		if(x && y) {
			System.out.println("condition is true");		
		}
		else {
			System.out.println("condition is false");
		}

	}*/
	/*
	 * boolean x = true; boolean y = false; if(x || y) {
	 * System.out.println("condition is true"); } else {
	 * System.out.println("condition is false"); }
	 */
	/*
	 * int a= 6; int b = 3; if((a>b) || (a<b)) {
	 * System.out.println("condition is true"); } else {
	 * System.out.println("condition is false"); }
	 */
	/*
	 * int ageofboy= 21; int ageofgirl = 16; if((ageofboy>=21) && (ageofgirl>=18)) {
	 * System.out.println("they can marry"); } else {
	 * System.out.println("they cannot marry"); }
	 */
	/*terinary operator
	 * int x; x = (4>5)?10:5; System.out.println(x);
	 */
		//Assignment Operators
		int x=6;
		x +=10;//x=x+10;
		x -=10;//x=x-10;
		x *=5;//x=x*10;
		x /=5;// x=x/5;
		x %=4;// remainder when x divided by 4
		System.out.println(x);

	}

}
