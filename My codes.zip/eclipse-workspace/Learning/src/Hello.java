import java.math.BigDecimal;

public class Hello {

	public static void main(String[] args) {
		//Int variable
		/*
		 * int a=1; int b=3; int c =a*b+b; System.out.println(c);
		 * 
		 * String value1="Mani"; String value2="Dath"; String value3=value1+value2;
		 * System.out.println(value3);
		 */
		
		/*double variable
		 * int dividend= 150; double percentage=dividend*0.29f;
		 * System.out.println("Percentage :"+percentage);
		 */
		/*boolean
		 * boolean var=true; System.out.println(var); char var1='\u00A7';
		 * System.out.println(var1);
		 */
		/*big decimal
		 * double x=1.05; double y=2.55; BigDecimal b1=new BigDecimal("1.05");
		 * BigDecimal b2=new BigDecimal("2.55"); System.out.println(x+y);
		 * System.out.println(b1.add(b2));
		 */
		/*string
		 * String var=new String ("Hello User"); System.out.println(var);
		 */
		/* Type Casting
		 * int x=10; short y=(short)x; System.out.println(y);
		 * 
		 * double v2=20.0d; float v1=(float)v2; System.out.println(v2);
		 */
		
		/*example
		 * int a=2; float b=2.225f; int value = (int)(a*a+2*(a*b)+b*b);
		 * System.out.println(value);
		 */
		
		
	}

}
