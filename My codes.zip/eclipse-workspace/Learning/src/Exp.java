
public class Exp {

	public static void main(String[] args) {
		/*
		 * for(int num=1;num<20;num++) { boolean flag= false; for(int i =2; i<=num/2;
		 * i++) { if (num%i ==0) { flag=true; break;
		 * 
		 * } } if(!flag){ System.out.println("prime number"+num); }else {
		 * System.out.println("not prime"+num); }
		 * 
		 * 
		 * }
		 */
		int num=1234;
		int sumofDigits=0;;
		while(true) {
			sumofDigits=sumofDigits+num%10;
			num=num/10;
			if(num<10) {
				break;
			}
		}sumofDigits=sumofDigits+num;
		System.out.println(sumofDigits);
	}
	
}
