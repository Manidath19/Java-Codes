/**
 * 
 */
/**
 * @author manid
 *
 */
module InitialArray {
}