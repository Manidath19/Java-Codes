package org.learning;

public class Demo {

	public static void main(String[] args) {
		String[] stringArray = {"Mani","kittu","pc","sindhu","prasanna"};
		for(String name:stringArray) {
			System.out.println(name);
		}
		for(int i=0;i<stringArray.length;i++) {
			System.out.println(stringArray[i]);
		}
	}

}
