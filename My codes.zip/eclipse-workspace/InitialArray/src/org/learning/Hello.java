package org.learning;

public class Hello {

	public static void main(String[] args) {
		String[] names = {"Mani","kittu","pc","sindhu","prasanna"};
		Hello hello = new Hello();
		hello.displayNames(names);
		System.out.println(names[0]);

	}
	void displayNames(String[] names) {
		names[0] = "Mahesh";
		for(String name: names) {
			System.out.println(name);
		}
		
		
	}

	
}
