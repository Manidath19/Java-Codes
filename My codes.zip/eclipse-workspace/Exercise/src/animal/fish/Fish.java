package animal.fish;

import animal.Animal;

public class Fish extends Animal{

	protected boolean waterBorn = true;
	protected boolean gills = true;

	public Fish() {
		animalType="water born";
		this.waterBorn = true;
		this.gills = true;
	}

	public String showInfo() {
		return "Fish [waterBorn=" + waterBorn + ", gills=" + gills + ", heightInFeet=" + heightInFeet
				+ ", weightInKilos=" + weightInKilos + ", animalType=" + animalType + ", bloodType=" + bloodType + "]";
	}
	

}
