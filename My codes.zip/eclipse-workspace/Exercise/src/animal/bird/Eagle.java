package animal.bird;

public class Eagle extends Bird {

	
	public String showInfo() {
		return "Eagle [feather=" + feather + ", canFly=" + canFly + ", heightInFeet=" + heightInFeet
				+ ", weightInKilos=" + weightInKilos + ", animalType=" + animalType + ", bloodType=" + bloodType + "]";
	}

}
