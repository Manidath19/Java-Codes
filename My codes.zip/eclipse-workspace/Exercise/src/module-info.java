/**
 * 
 */
/**
 * @author manid
 *
 */
module Exercise {
}