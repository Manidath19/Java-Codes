/**
 * 
 */
/**
 * @author manid
 *
 */
module StaticElements {
}