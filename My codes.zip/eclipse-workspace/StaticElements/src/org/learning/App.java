package org.learning;
import org.learning.testrun.*;
public class App {

	public static void main(String[] args) {
	
		System.out.println("current obj1:"+TestStatic.getTestStatic());
		TestStatic.setTestStatic(2);
		System.out.println("current obj1:"+TestStatic.getTestStatic());
		TestStatic.setTestStatic(20);
		System.out.println("current obj2:"+TestStatic.getTestStatic());
	}

}
