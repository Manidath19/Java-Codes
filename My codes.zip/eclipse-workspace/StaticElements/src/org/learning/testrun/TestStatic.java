package org.learning.testrun;

public class TestStatic {
	private static int testStatic = 1;

	public static int getTestStatic() {
		return testStatic;
	}

	public static void setTestStatic(int testStatic) {
		TestStatic.testStatic = testStatic;
	}
	
}
