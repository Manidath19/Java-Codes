/**
 * 
 */
/**
 * @author manid
 *
 */
module Iterator {
}