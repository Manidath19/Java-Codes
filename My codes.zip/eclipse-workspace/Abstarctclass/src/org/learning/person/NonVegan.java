package org.learning.person;

public class NonVegan extends Person {

	@Override
	public void eat() {
		System.out.println("Person eats non vegan food");
		
	}

}
