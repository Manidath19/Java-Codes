package org.learning.person;

public abstract class Person {
	public void speak() {
		System.out.println("person speaking is he/her");
	}
	public abstract void eat();

}
