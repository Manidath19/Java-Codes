package org.learning;
import org.learning.person.Person;
import org.learning.person.Vegan;
import org.learning.person.NonVegan;


public class Hello {

	public static void main(String[] args) {
		Person john = new Vegan();
		john.speak();
		john.eat();
		System.out.println("***********");
		Person ram = new NonVegan();
		ram.speak();
		ram.eat();

	}

}
