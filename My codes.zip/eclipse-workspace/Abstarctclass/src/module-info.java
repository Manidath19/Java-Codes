/**
 * 
 */
/**
 * @author manid
 *
 */
module Abstarctclass {
}