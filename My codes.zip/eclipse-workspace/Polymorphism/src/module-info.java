/**
 * 
 */
/**
 * @author manid
 *
 */
module Polymorphism {
}