package org.learning;
import org.learning.phone.*;
public class Hello {

	public static void main(String[] args) {
	
		
		Phone note10 = new Hello().phone(1);
		System.out.println(note10.getModel());
		note10.features();
		
		Phone nokia = new Hello().phone(2);
		System.out.println(nokia.getModel());
		nokia.features();
	}
 public Phone phone(int dailyDriver) {
	 switch(dailyDriver) {
	 case 1: return new Samsung("Note10");
	 case 2: return new Nokia("Nokia 3310");
	 }
	return null;
	 
 }
}
