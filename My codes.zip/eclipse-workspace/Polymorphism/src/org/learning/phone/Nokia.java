package org.learning.phone;

public class Nokia extends Phone {

	public Nokia(String model) {
		super(model);
		// TODO Auto-generated constructor stub
	}

}
