/**
 * 
 */
/**
 * @author manid
 *
 */
module Encapsulation {
}