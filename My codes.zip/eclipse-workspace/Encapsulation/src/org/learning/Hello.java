package org.learning;

public class Hello {

	public static void main(String[] args) {
	 Person mani = new Person();
	 System.out.println(mani);
	 Person sree = new Person("sree", 25, "Female");
	 System.out.println(sree);
	 sree.setAge(-10);
	 System.out.println(sree);

	}

}
