package org.learning.demo;

public class Outer {
	private static int o=5;
	public static void outerMethod() {
		System.out.println("Testing Inner Method value:"+Inner.x);
		Inner.innerMethod();
	}
	public static class Inner{
		public static int x=10;
		public static void innerMethod() {
			System.out.println("Testing Inner static class");
			
		}
	}

}
