package org.learning;
import org.learning.demo.*;
public class App {

	public static void main(String[] args) {
		Outer.outerMethod();
		//System.out.println(Outer.Inner.x);

	}

}
