/**
 * 
 */
/**
 * @author manid
 *
 */
module StaticInnerClass {
}