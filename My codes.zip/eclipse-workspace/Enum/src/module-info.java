/**
 * 
 */
/**
 * @author manid
 *
 */
module Enum {
}