package org.learning;

public enum Learning {
	JAVA, COLLECTIONS, GENERICS, MULTITHREADING, JSP

}
