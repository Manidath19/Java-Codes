package org.learning;

public class Demo {

	public static void main(String[] args) {
		Learning learn = Learning.JSP;
		switch(learn) {
		case COLLECTIONS:
			System.out.println("COLLECTIONS");
			break;
		case GENERICS:
			System.out.println("COLLECTIONS");
			break;
		case JAVA:
			System.out.println("JAVA");
			break;
		case JSP:
			System.out.println("JSP");
			break;
		case MULTITHREADING:
			System.out.println("MULTITHREADING");
			break;
		default:
			break;
		
		}

	}

}
