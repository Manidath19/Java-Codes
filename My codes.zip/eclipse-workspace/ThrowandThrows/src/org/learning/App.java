package org.learning;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class App {
public static void main(String[] args) throws FileNotFoundException {
	someMethod();
}
public static void someMethod() throws FileNotFoundException{
	FileReader fr = new FileReader("new.txt");
	System.out.println("message from somemethod");
}
}
