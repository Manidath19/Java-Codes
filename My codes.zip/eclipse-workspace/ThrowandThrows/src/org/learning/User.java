package org.learning;

import java.io.FileNotFoundException;
class UserDefinedException extends Exception{
	
}
public class User {

	
	public static void main(String[] args) {
		try {
			someMethod();
		} catch (FileNotFoundException e) {
			System.out.println("Inside file not found");
			e.printStackTrace();
		} catch (UserDefinedException e) {
			System.out.println("Inside UserDefinedException");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("Inside exception");
			e.printStackTrace();
		}
	}
	public static void someMethod() throws Exception, FileNotFoundException, UserDefinedException{
		int x= 3;
		switch(x) {
		case 1: throw new FileNotFoundException();
		
		case 2: throw new Exception();
		default: throw new UserDefinedException();
		
		}
	}
}
