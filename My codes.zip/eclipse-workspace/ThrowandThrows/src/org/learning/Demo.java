package org.learning;

import java.io.FileNotFoundException;

public class Demo {

	public static void main(String[] args) {
		try {
			someMethod();
		} catch (FileNotFoundException e) {
			System.out.println("Inside file not found");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Inside exception");
			e.printStackTrace();
		}
	}
	public static void someMethod() throws FileNotFoundException{
		System.out.println("message from somemethod");
		throw new FileNotFoundException();
	}

}
