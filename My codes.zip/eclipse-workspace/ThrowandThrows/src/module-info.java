/**
 * 
 */
/**
 * @author manid
 *
 */
module ThrowandThrows {
}