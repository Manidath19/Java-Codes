/**
 * 
 */
/**
 * @author manid
 *
 */
module UserInput {
}