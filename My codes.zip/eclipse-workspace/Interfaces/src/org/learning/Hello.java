package org.learning;
import org.learning.phone.*;
import org.learning.phone.OnePlus5;

public class Hello {

	public static void main(String[] args) {
		Phone phone = new OnePlus5();
		System.out.println("OnePlus5 Processor: "+phone.processor());
		
		Phone iphone = new Iphone8();
		System.out.println("Iphone8 Processor: "+iphone.processor());
		

	}

}
