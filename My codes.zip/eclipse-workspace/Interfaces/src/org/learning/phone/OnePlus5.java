package org.learning.phone;

public class OnePlus5 implements Phone {

	@Override
	public String processor() {
		// TODO Auto-generated method stub
		return "SD835";
	}

	@Override
	public String os() {
		// TODO Auto-generated method stub
		return "Android";
	}

	@Override
	public int spaceINGB() {
		// TODO Auto-generated method stub
		return 64;
	}
	


}
