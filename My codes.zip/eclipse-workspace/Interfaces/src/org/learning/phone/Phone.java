package org.learning.phone;

public interface Phone {
	String processor();
	String os();
	int spaceINGB();

}
