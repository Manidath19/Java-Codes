package org.learning.phone;

public class Iphone8 implements Phone{

	@Override
	public String processor() {
		// TODO Auto-generated method stub
		return "A11";
	}

	@Override
	public String os() {
		// TODO Auto-generated method stub
		return "IOS";
	}

	@Override
	public int spaceINGB() {
		// TODO Auto-generated method stub
		return 64;
	}

}
