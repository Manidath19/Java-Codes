/**
 * 
 */
/**
 * @author manid
 *
 */
module Interfaces {
}