/**
 * 
 */
/**
 * @author manid
 *
 */
module StackMethods {
}