package org.learning;
import org.learning.shop.*;

public class Shop {

	public static void main(String[] args) {
		Door door = new Door();
		if(door.isLocked(args[0])) {
			System.out.println("shop closed");
		}else {
			System.out.println("shop open");
		}
		

	}

}
