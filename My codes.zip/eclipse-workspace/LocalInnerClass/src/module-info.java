/**
 * 
 */
/**
 * @author manid
 *
 */
module InnerClass {
}