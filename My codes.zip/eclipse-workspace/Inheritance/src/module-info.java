/**
 * 
 */
/**
 * @author manid
 *
 */
module Inheritance {
}