package org.learn;
import org.learn.vehicles.Bike;
import org.learn.vehicles.Car;
public class Demo {

	public static void main(String[] args) {
		Bike bike=new Bike("short","diesel",4,4,"on");
		System.out.println(bike.getHandle());
		System.out.println(bike.getEngine());
		System.out.println(bike);
		bike.run();
		
		
		

	}

}
