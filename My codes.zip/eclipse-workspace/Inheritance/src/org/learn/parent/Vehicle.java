package org.learn.parent;

public class Vehicle {

private String engine;
private int wheels;
private int seats;
private String lights;
public Vehicle() {
	this.engine = "petrol";
	this.wheels = 2;
	this.seats = 2;
	this.lights = "on";
}
public Vehicle(String engine, int wheels, int seats, String lights) {
	
	this.engine = engine;
	this.wheels = wheels;
	this.seats = seats;
	this.lights = lights;
}
public String getEngine() {
	return engine;
}
public int getWheels() {
	return wheels;
}
public int getSeats() {
	return seats;
}
public String getLights() {
	return lights;
}
public void run() {
	System.out.println("Running vehicle");
}


}
