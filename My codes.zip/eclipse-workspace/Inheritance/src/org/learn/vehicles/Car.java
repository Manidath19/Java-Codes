package org.learn.vehicles;

import org.learn.parent.Vehicle;

public class Car extends Vehicle {

	private String airConditioner;
	private String musicSystem;
	private String steering;
	public Car() {
		super();
		this.airConditioner = "on";
		this.musicSystem = "working";
		this.steering = "present";
	}
	public Car(String airConditioner, String musicSystem, String steering) {
		super();
		this.airConditioner = airConditioner;
		this.musicSystem = musicSystem;
		this.steering = steering;
	}
	public String getAirConditioner() {
		return airConditioner;
	}
	public String getMusicSystem() {
		return musicSystem;
	}
	public String getSteering() {
		return steering;
	}
	
	
}
