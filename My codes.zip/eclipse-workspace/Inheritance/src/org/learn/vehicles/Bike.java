package org.learn.vehicles;

import org.learn.parent.Vehicle;

public class Bike extends Vehicle {

	private String handle;
	

	public Bike() {
		super();
		this.handle = "long";
	}


	public Bike(String handle,String engine, int wheels, int seats, String lights) {
		super(engine,wheels,seats,lights);
		this.handle = handle;
	}


	public String getHandle() {
		return handle;
	}


	@Override
	public String toString() {
		return "Bike [getHandle()=" + getHandle() + ", getEngine()=" + getEngine() + ", getWheels()=" + getWheels()
				+ ", getSeats()=" + getSeats() + ", getLights()=" + getLights() + "]";
	}
	public void run() {
		System.out.println("Running bike");
		System.out.println(toString());
	}
	
	

}
