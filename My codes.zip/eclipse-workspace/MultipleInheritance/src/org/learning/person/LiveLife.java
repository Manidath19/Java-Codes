package org.learning.person;

public interface LiveLife {
	void message();
}
