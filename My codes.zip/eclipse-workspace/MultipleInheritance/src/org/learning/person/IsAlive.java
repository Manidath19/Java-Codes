package org.learning.person;

public interface IsAlive {
	void breathe();
}
