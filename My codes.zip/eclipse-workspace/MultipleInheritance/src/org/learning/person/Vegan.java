package org.learning.person;

public class Vegan extends Person {

	@Override
	public void eat() {
		System.out.println("eats vegan");
		
	}

}
