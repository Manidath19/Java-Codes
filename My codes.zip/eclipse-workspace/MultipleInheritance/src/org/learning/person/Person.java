package org.learning.person;

public abstract class Person implements IsAlive,LiveLife{
	public void speak() {
		System.out.println("his/her thoughts");
	}
	@Override
	public void breathe() {
		System.out.println("be alive");
	}
	@Override
	public void message() {
		System.out.println("keep moving");
	}
	public  abstract void eat();

}
