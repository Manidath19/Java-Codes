package org.learning;
import org.learning.person.*;
public class Hello {

	public static void main(String[] args) {
		Person john = new Vegan();
		john.breathe();
		john.eat();
		john.speak();
		john.message();
		

	}

}
