/**
 * 
 */
/**
 * @author manid
 *
 */
module MultipleInheritance {
}